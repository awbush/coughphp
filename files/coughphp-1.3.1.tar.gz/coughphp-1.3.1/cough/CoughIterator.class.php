<?php

/**
 * CoughCollection objects use CoughIterator
 * 
 * @package cough
 **/
class CoughIterator extends ArrayIterator
{
}

?>