<?php
// PDO is not currently supported, but you should be able to just fill this class in like with CoughAsDatabase.
class CoughPdoDatabase extends PDO implements CoughDatabaseInterface
{
	
}
?>