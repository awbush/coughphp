DROP TABLE IF EXISTS `author`;
DROP TABLE IF EXISTS `book`;
DROP TABLE IF EXISTS `book2library`;
DROP TABLE IF EXISTS `library`;
DROP TABLE IF EXISTS `table_without_auto_increment`;
