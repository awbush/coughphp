<?php

/**
* This is the starter class for TableOne_Collection_Generated.
 *
 * @see TableOne_Collection_Generated, CoughCollection
 **/
class TableOne_Collection extends TableOne_Collection_Generated {
}

?>