<?php

/**
 * This is the base class for TableOne_Collection.
 *
 * @see TableOne_Collection, CoughCollection
 **/
abstract class TableOne_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'TableOne';
}

?>