<?php

/**
 * This is the starter class for TableOne_Generated.
 *
 * @see TableOne_Generated, CoughObject
 **/
class TableOne extends TableOne_Generated implements CoughObjectStaticInterface {
}

?>