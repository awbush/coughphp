<?php

/**
 * This is the starter class for Customer_Generated.
 *
 * @see Customer_Generated, CoughObject
 **/
class Customer extends Customer_Generated implements CoughObjectStaticInterface {
}

?>