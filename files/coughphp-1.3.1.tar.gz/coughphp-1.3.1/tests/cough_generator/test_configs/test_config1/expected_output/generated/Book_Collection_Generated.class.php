<?php

/**
 * This is the base class for Book_Collection.
 *
 * @see Book_Collection, CoughCollection
 **/
abstract class Book_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'Book';
}

?>