<?php

/**
 * This is the base class for Book2library_Collection.
 *
 * @see Book2library_Collection, CoughCollection
 **/
abstract class Book2library_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'Book2library';
}

?>