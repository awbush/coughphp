<?php

/**
 * This is the starter class for Book2library_Generated.
 *
 * @see Book2library_Generated, CoughObject
 **/
class Book2library extends Book2library_Generated implements CoughObjectStaticInterface {
}

?>