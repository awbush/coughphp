<?php

/**
 * This is the starter class for Library_Generated.
 *
 * @see Library_Generated, CoughObject
 **/
class Library extends Library_Generated implements CoughObjectStaticInterface {
}

?>