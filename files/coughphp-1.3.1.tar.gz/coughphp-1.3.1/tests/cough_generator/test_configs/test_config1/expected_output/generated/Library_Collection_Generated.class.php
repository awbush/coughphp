<?php

/**
 * This is the base class for Library_Collection.
 *
 * @see Library_Collection, CoughCollection
 **/
abstract class Library_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'Library';
}

?>