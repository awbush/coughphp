<?php

/**
 * Global/shared DSN config for all tests
 * 
 * @var array
 **/
$dsn = array(
	'host' => 'localhost',
	'user' => 'cough_test',
	'pass' => 'cough_test',
	'port' => 3306,
	'driver' => 'mysql',
	'db_name' => 'test_cough_object',
);

?>