<?php

// Load the core schema classes
include_once('SchemaColumn.class.php');
include_once('SchemaDatabase.class.php');
include_once('Schema.class.php');
include_once('SchemaTable.class.php');
include_once('SchemaForeignKey.class.php');
include_once('SchemaRelationship.class.php');
include_once('SchemaRelationshipHasOne.class.php');
include_once('SchemaRelationshipHasMany.class.php');
include_once('SchemaManipulator.class.php');

?>