This software is protected by the FreeBSD License (revised).  See license.txt for more info.

For documentation, see the website:
http://coughphp.com/
http://coughphp.com/docs/

Don't forget about the IRC channel #coughphp on irc.freenode.net!

Thank you for checking out CoughPHP!
