<?php

/**
 * The query result object returned by {@link CoughAsDatabase::query()}.
 * 
 * @package as_database
 **/
class CoughAsDatabaseResult extends As_DatabaseResult implements CoughDatabaseResultInterface
{
	
}
?>