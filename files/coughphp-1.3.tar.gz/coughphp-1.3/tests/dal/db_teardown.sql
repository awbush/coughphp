DROP TABLE IF EXISTS `person`;
DROP TABLE IF EXISTS `person2school`;
DROP TABLE IF EXISTS `person2school_type`;
DROP TABLE IF EXISTS `political_party`;
DROP TABLE IF EXISTS `school_type_empty_table`;
DROP TABLE IF EXISTS `school_type`;
DROP TABLE IF EXISTS `school`;
