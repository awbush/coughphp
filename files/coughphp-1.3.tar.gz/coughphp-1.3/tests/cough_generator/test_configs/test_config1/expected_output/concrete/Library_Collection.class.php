<?php

/**
* This is the starter class for Library_Collection_Generated.
 *
 * @see Library_Collection_Generated, CoughCollection
 **/
class Library_Collection extends Library_Collection_Generated {
}

?>