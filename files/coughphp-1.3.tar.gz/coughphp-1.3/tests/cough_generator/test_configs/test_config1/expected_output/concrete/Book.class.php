<?php

/**
 * This is the starter class for Book_Generated.
 *
 * @see Book_Generated, CoughObject
 **/
class Book extends Book_Generated implements CoughObjectStaticInterface {
}

?>