<?php

/**
* This is the starter class for Author_Collection_Generated.
 *
 * @see Author_Collection_Generated, CoughCollection
 **/
class Author_Collection extends Author_Collection_Generated {
}

?>