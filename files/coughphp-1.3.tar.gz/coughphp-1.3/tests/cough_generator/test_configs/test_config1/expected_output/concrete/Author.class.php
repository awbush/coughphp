<?php

/**
 * This is the starter class for Author_Generated.
 *
 * @see Author_Generated, CoughObject
 **/
class Author extends Author_Generated implements CoughObjectStaticInterface {
}

?>