<?php

/**
* This is the starter class for Book_Collection_Generated.
 *
 * @see Book_Collection_Generated, CoughCollection
 **/
class Book_Collection extends Book_Collection_Generated {
}

?>