<?php

/**
* This is the starter class for Book2library_Collection_Generated.
 *
 * @see Book2library_Collection_Generated, CoughCollection
 **/
class Book2library_Collection extends Book2library_Collection_Generated {
}

?>