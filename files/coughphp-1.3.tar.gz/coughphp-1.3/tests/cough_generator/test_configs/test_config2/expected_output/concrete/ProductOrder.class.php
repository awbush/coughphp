<?php

/**
 * This is the starter class for ProductOrder_Generated.
 *
 * @see ProductOrder_Generated, CoughObject
 **/
class ProductOrder extends ProductOrder_Generated implements CoughObjectStaticInterface {
}

?>