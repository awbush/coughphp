<?php

/**
* This is the starter class for ProductOrder_Collection_Generated.
 *
 * @see ProductOrder_Collection_Generated, CoughCollection
 **/
class ProductOrder_Collection extends ProductOrder_Collection_Generated {
}

?>