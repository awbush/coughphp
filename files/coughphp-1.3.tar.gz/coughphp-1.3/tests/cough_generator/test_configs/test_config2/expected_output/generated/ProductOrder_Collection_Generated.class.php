<?php

/**
 * This is the base class for ProductOrder_Collection.
 *
 * @see ProductOrder_Collection, CoughCollection
 **/
abstract class ProductOrder_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'ProductOrder';
}

?>