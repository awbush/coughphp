<?php

/**
 * This is the starter class for Product_Generated.
 *
 * @see Product_Generated, CoughObject
 **/
class Product extends Product_Generated implements CoughObjectStaticInterface {
}

?>