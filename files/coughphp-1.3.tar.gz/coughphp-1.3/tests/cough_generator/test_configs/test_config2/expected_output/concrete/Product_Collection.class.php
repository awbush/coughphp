<?php

/**
* This is the starter class for Product_Collection_Generated.
 *
 * @see Product_Collection_Generated, CoughCollection
 **/
class Product_Collection extends Product_Collection_Generated {
}

?>