<?php

/**
* This is the starter class for Customer_Collection_Generated.
 *
 * @see Customer_Collection_Generated, CoughCollection
 **/
class Customer_Collection extends Customer_Collection_Generated {
}

?>