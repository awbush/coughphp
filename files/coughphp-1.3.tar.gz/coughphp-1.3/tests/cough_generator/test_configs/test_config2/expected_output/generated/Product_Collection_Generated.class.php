<?php

/**
 * This is the base class for Product_Collection.
 *
 * @see Product_Collection, CoughCollection
 **/
abstract class Product_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'Product';
}

?>