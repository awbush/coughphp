<?php

/**
 * This is the base class for Customer_Collection.
 *
 * @see Customer_Collection, CoughCollection
 **/
abstract class Customer_Collection_Generated extends CoughCollection {
	protected $dbAlias = 'test_cough_object';
	protected $dbName = 'test_cough_object';
	protected $elementClassName = 'Customer';
}

?>