DROP TABLE IF EXISTS `product_order`;
DROP TABLE IF EXISTS `product`;
DROP TABLE IF EXISTS `customer`;
