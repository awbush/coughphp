<?php
class CoughPdoDatabase extends PDO implements CoughDatabaseInterface
{
	
}
?>