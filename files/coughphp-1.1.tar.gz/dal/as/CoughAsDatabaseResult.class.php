<?php
class CoughAsDatabaseResult extends As_DatabaseResult implements CoughDatabaseResultInterface
{
	
}
?>