<?php

/**
 * undocumented class CoughIterator
 * 
 * @package cough
 **/
class CoughIterator extends ArrayIterator {
}


?>
