<?php

/**
 * This interface must be implemented in the concrete/generated classes.
 *
 * @author Anthony Bush
 **/
interface CoughObjectStaticInterface
{
	public static function getDb();
	public static function getDbName();
	public static function getTableName();
	public static function getPkFieldNames();
	public static function getLoadSql();
	public static function constructByFields($hash);
	public static function constructByKey($idOrHash);
	public static function constructBySql($sql);
}

?>