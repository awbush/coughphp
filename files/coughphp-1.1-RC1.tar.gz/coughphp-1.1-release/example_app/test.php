<?php

error_reporting(E_ALL);

define('APP_PATH', dirname(__FILE__) . '/');

// Load up the Cough Module
$coughModulePath = dirname(dirname(__FILE__)) . '/';
include_once($coughModulePath . 'load.inc.php');

// Load up the autoloader and configure it
include_once($coughModulePath . 'extras/Autoloader.class.php');
Autoloader::addClassPath(APP_PATH . 'models/');
Autoloader::setCacheFilePath(APP_PATH . 'tmp/class_path_cache.txt');
Autoloader::excludeFolderNamesMatchingRegex('/^CVS|\..*$/');
spl_autoload_register(array('Autoloader', 'loadClass'));

// Setup the Database infos (will be lazy-connected to)
$dbConfig = array(
	'adapter' => 'as',
	'driver' => 'mysql',
	'host' => 'dev',
	'user' => 'nobody',
	'pass' => ''
);
CoughDatabaseFactory::addDatabaseConfig('erik_portfolio', $dbConfig);

// Try to instantiate a class
$project = new Project();
$project->setName('Test Project');

if ($project->save()) {
	echo 'Project saved to ID ' . $project->getKeyId();
} else {
	echo 'Unable to save project';
}
echo "\n";

?>