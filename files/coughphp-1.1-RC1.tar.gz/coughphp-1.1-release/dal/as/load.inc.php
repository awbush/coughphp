<?php
require_once('As_Database.class.php');
require_once('As_DatabaseResult.class.php');
require_once('As_SqlFunction.class.php');
// require_once('As_DatabaseFactory.class.php');
?>