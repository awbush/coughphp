<?php

// This file exists for backward-compatibility.  To load cough use the line
// below instead of the line to include this file.
require_once('cough/load.inc.php');

?>