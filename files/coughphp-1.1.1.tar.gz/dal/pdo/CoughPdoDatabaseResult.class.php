<?php
class CoughPdoDatabaseResult implements CoughDatabaseInterface
{
	
}
?>