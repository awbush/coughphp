<?php
include_once('As_Query.class.php');
include_once('As_InsertQuery.class.php');
include_once('As_UpdateQuery.class.php');
include_once('As_SelectQuery.class.php');
?>